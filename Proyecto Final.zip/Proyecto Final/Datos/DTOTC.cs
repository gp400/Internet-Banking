﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Datos
{
    public class DTOTC
    {
        public int IdTarjeta { get; set; }
        public string Bin { get; set; } = null!;
        public int Cvv { get; set; }
        public DateTime Vencimiento { get; set; }
        public decimal Monto { get; set; }
        public decimal TarjetaBalance { get; set; }
        public int IdCuenta { get; set; }
        public string NoCuenta { get; set; } = null!;
        public decimal CuentaBalance { get; set; }
    }
}
