﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Datos
{
    public class DTOTarjetas
    {
        public int idCliente { get; set; }
        public string Cedula { get; set; }
        public string Nombres { get; set; }
        public string Apellidos { get; set; }
        public string Email { get; set; }
        public int idTarjeta { get; set; }
        public string Bin { get; set; }
        public int Cvv { get; set; }
        public DateTime Vencimiento { get; set; }
        public decimal Monto { get; set; }
        public decimal Balance { get; set; }
    }
}
