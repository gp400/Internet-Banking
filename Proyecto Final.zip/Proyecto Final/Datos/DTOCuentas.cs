﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Datos
{
    public class DTOCuentas
    {
        public int idCliente { get; set; }
        public string Cedula { get; set; }
        public string Nombres { get; set; }
        public string Apellidos { get; set; }
        public string Email { get; set; }
        public int idCuenta { get; set; }
        public string NoCuenta { get; set; }
        public decimal Balance { get; set; }
    }
}
