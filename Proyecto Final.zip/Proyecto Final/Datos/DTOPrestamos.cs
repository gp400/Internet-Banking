﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Datos
{
    public class DTOPrestamos
    {
        public int idCliente { get; set; }
        public int idPrestamo { get; set; }
        public string Cedula { get; set; }
        public string Nombres { get; set; }
        public string Apellidos { get; set; }
        public string Email { get; set; } = null!;
        public decimal Monto { get; set; }
        public decimal TotalPagado { get; set; }
        public DateTime? FechaInicial { get; set; }
        public DateTime? FechaLimite { get; set; }
    }
}
