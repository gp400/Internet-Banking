﻿using Microsoft.EntityFrameworkCore;

namespace Datos
{
    using Models;
    public class Database
    {
        static proyecto_finalContext db = new();
        public static object[] Login(string username, string password)
        {
            try
            {
                return new object[] { db.LoginEmpleados.Where(LE => LE.Usuario == username && LE.Constraseña == Hash.Hashear(password) && LE.Activo == 1).First() };
            } catch(Exception e)
            {
                return new object[] { db.Clientes.Where(C => C.Cedula == username && C.Constraseña == Hash.Hashear(password) && C.Activo == 1).First() };
            }
        }

        public static List<Cliente> getClientes()
        {
            return db.Clientes.Where(cliente=>cliente.Activo==1).ToList();
        }

        public static void SaveClientes(Cliente cliente)
        {
            db.Clientes.Add(cliente);
            cliente.Constraseña = Hash.Hashear(cliente.Constraseña);
            db.SaveChanges();
        }

        public static Cliente getCliente(int id)
        {
            return db.Clientes.First(cliente=>cliente.Id==id);
        }

        public static void updateCliente(Cliente cliente)
        {
            Cliente datos = db.Clientes.First(c => c.Id == cliente.Id);
            datos.Cedula = cliente.Cedula;
            datos.Nombres = cliente.Nombres;
            datos.Apellidos = cliente.Apellidos;
            datos.Email = cliente.Email;
            datos.Constraseña = Hash.Hashear(cliente.Constraseña);
            db.SaveChanges();
        }

        public static void deleteCliente(int id)
        {
            Cliente cliente=db.Clientes.First(c=>c.Id==id);
            cliente.Activo = 0;
            List<Prestamo> prestamos=db.Prestamos.Where(prestamos=>prestamos.IdCliente==id).ToList();
            foreach(Prestamo prestamo in prestamos)
            {
                prestamo.Activo = 0;
            }
            List<Cuenta> cuentas = db.Cuentas.Where(cuentas => cuentas.IdCliente == id).ToList();
            foreach(Cuenta cuenta in cuentas)
            {
                cuenta.Activo = 0;
            }
            List<Tarjeta> tarjetas = db.Tarjetas.Where(tarjetas => tarjetas.IdCliente == id).ToList();
            foreach(Tarjeta tarjeta in tarjetas)
            {
                tarjeta.Activo = 0;
            }
            db.SaveChanges();
        }

        public static List<DTOPrestamos> getPrestamos()
        {
            List<DTOPrestamos> prestamos = new List<DTOPrestamos>();
            foreach(Prestamo prestamo in db.Prestamos.Where(p=>p.Activo==1).ToList())
            {
                Cliente cliente = db.Clientes.Where(cli => cli.Id == prestamo.IdCliente).First();
                prestamos.Add(new DTOPrestamos
                {
                    idCliente = cliente.Id,
                    idPrestamo = prestamo.Id,
                    Cedula =cliente.Cedula,
                    Nombres=cliente.Nombres,
                    Apellidos=cliente.Apellidos,
                    Email=cliente.Email,
                    Monto= prestamo.Monto,
                    TotalPagado=prestamo.TotalPagado,
                    FechaInicial=prestamo.FechaInicial,
                    FechaLimite=prestamo.FechaLimite
                });
            }
            return prestamos;
        }

        public static List<Prestamo> getPrestamosWhere(int id)
        {
            return db.Prestamos.Where(p => p.IdCliente == id && p.Activo == 1).ToList();
        }

        public static void SavePrestamos(Prestamo prestamo)
        {
            db.Prestamos.Add(prestamo);
            db.SaveChanges();
        }

        public static DTOPrestamos getPrestamo(int id)
        {
            Prestamo prestamo = db.Prestamos.First(p => p.Id==id);
            Cliente cliente = db.Clientes.First(c => c.Id == prestamo.IdCliente);
            return new DTOPrestamos
            {
                idCliente=cliente.Id,
                idPrestamo=prestamo.Id,
                Cedula = cliente.Cedula,
                Nombres = cliente.Nombres,
                Apellidos = cliente.Apellidos,
                Email = cliente.Email,
                Monto = prestamo.Monto,
                TotalPagado = prestamo.TotalPagado,
                FechaInicial = prestamo.FechaInicial,
                FechaLimite = prestamo.FechaLimite
            };
        }

        public static void updatePrestamo(Prestamo prestamo)
        {
            Prestamo prestamotabla = db.Prestamos.First(p => p.Id == prestamo.Id);
            prestamotabla.Monto = prestamo.Monto;
            prestamotabla.TotalPagado += prestamo.TotalPagado;
            prestamotabla.FechaInicial = prestamo.FechaInicial;
            prestamotabla.FechaLimite = prestamo.FechaLimite;
            prestamotabla.IdCliente = prestamo.IdCliente;
            db.SaveChanges();
        }

        public static void deletePrestamos(int id)
        {
            Prestamo prestamo = db.Prestamos.First(p=>p.Id==id);
            prestamo.Activo = 0;
            db.SaveChanges();
        }

        public static void pagarPrestamo(Prestamo prestamo)
        {
            Prestamo datos = db.Prestamos.First(p=>p.Id==prestamo.Id);
            Cuenta cuenta = db.Cuentas.First(c => c.Id == prestamo.IdCliente);
            if (cuenta.Balance>=prestamo.TotalPagado)
            {
                datos.TotalPagado += prestamo.TotalPagado;
                cuenta.Balance -= prestamo.TotalPagado;
                Historial historial = new Historial
                {
                    Monto = prestamo.TotalPagado,
                    Producto = 1,
                    IdCliente = datos.IdCliente,
                    IdProducto = datos.Id,
                    Fecha = DateTime.Now
                };
                db.Historials.Add(historial);
                db.SaveChanges();
            }
            else
            {
                throw new Exception();
            }
        }
        public static List<Historial> HistorialPrestamos(int id)
        {
            try
            {
                return db.Historials.Where(h => h.IdProducto == id && h.Producto == 1).ToList();
            }
            catch (Exception e)
            {
                return new List<Historial>();
            }
        }

        public static List<Historial> HistorialPrestamos(int id, DateTime? inicial, DateTime? final)
        {
            try
            {
                return db.Historials.Where(h => h.Fecha >= inicial && h.Fecha <= final && h.IdProducto == id && h.Producto == 1).ToList();
            }
            catch (Exception e)
            {
                return new List<Historial>();
            }
        }

        public static List<DTOCuentas> getCuentas()
        {
            List<DTOCuentas> cuentas=new List<DTOCuentas>();
            foreach (Cuenta cuenta in db.Cuentas.Where(c => c.Activo == 1).ToList())
            {
                Cliente cliente = db.Clientes.First(cli => cli.Id == cuenta.IdCliente);
                cuentas.Add(new DTOCuentas
                {
                    idCliente=cliente.Id,
                    Cedula=cliente.Cedula,
                    Nombres=cliente.Nombres,
                    Apellidos=cliente.Apellidos,
                    Email=cliente.Email,
                    idCuenta=cuenta.Id,
                    NoCuenta=cuenta.NoCuenta,
                    Balance=cuenta.Balance
                });
            }
            return cuentas;
        }

        public static List<Cuenta> getCuentasWhere(int id)
        {
            return db.Cuentas.Where(c=>c.IdCliente==id && c.Activo==1).ToList();
        }

        public static void SaveCuentas(Cuenta cuenta)
        {
            db.Cuentas.Add(cuenta);
            db.SaveChanges();
        }

        public static DTOCuentas getCuenta(int id)
        {
            Cuenta cuenta = db.Cuentas.First(c => c.Id == id);
            Cliente cliente = db.Clientes.First(c => c.Id == cuenta.IdCliente);
            return new DTOCuentas
            {
                idCliente = cliente.Id,
                Cedula = cliente.Cedula,
                Nombres = cliente.Nombres,
                Apellidos = cliente.Apellidos,
                Email = cliente.Email,
                idCuenta = cuenta.Id,
                NoCuenta = cuenta.NoCuenta,
                Balance = cuenta.Balance
            };
        }

        public static void updateCuenta(Cuenta cuenta)
        {
            Cuenta datos = db.Cuentas.First(c => c.Id == cuenta.Id);
            datos.NoCuenta = cuenta.NoCuenta;
            datos.Balance += cuenta.Balance;
            datos.IdCliente = cuenta.IdCliente;
            db.SaveChanges();
        }

        public static void deleteCuenta(int id)
        {
            Cuenta cuenta = db.Cuentas.First(c => c.Id == id);
            cuenta.Activo = 0;
            db.SaveChanges();
        }

        public static void retiroCuenta(Cuenta cuenta)
        {
            Cuenta account = db.Cuentas.First(c => c.Id == cuenta.Id);
            if (account.Balance >= cuenta.Balance)
            {
                account.Balance -= cuenta.Balance;
                Historial historial = new Historial
                {
                    Monto = cuenta.Balance,
                    Tipo = "Retiro",
                    Producto=0,
                    IdCliente=account.IdCliente,
                    IdProducto=account.Id,
                    Fecha=DateTime.Now
                };
                db.Historials.Add(historial);
                db.SaveChanges();
            } else
            {
                throw new Exception();
            }
        }

        public static void depositoCuenta(Cuenta cuenta)
        {
            Cuenta account = db.Cuentas.First(c => c.Id == cuenta.Id);
            account.Balance += cuenta.Balance;
            Historial historial = new Historial
            {
                Monto = cuenta.Balance,
                Tipo = "Deposito",
                Producto = 0,
                IdCliente = account.IdCliente,
                IdProducto = account.Id,
                Fecha = DateTime.Now
            };
            db.Historials.Add(historial);
            db.SaveChanges();
        }

        public static List<Historial> HistorialCuentas(int id)
        {
            try
            {
                return db.Historials.Where(h => h.IdProducto == id && h.Producto == 0).ToList();
            } catch(Exception e)
            {
                return new List<Historial>();
            }
        }

        public static List<Historial> HistorialCuentas(int id, DateTime? inicial, DateTime? final)
        {
            try
            {
                return db.Historials.Where(h => h.Fecha >= inicial && h.Fecha <= final && h.IdProducto == id && h.Producto == 0).ToList();
            } catch (Exception e)
            {
                return new List<Historial>();
            }
        }

        public static void TransferenciaCuenta(Cuenta cuenta)
        {
            Cuenta agregar = db.Cuentas.First(c => c.NoCuenta == cuenta.NoCuenta);
            Cuenta resta = db.Cuentas.First(c => c.Id == cuenta.Id);
            agregar.Balance += cuenta.Balance;
            if (resta.Balance >= cuenta.Balance)
            {
                resta.Balance -= cuenta.Balance;
            } else
            {
                throw new Exception();
            }
            db.SaveChanges();
        }

        public static List<DTOTarjetas> getTarjetas()
        {
            List<DTOTarjetas> tarjetas = new List<DTOTarjetas>();
            foreach(Tarjeta tarjeta in db.Tarjetas.Where(t => t.Activo == 1).ToList())
            {
                Cliente cliente = db.Clientes.First(c => c.Id == tarjeta.IdCliente);
                tarjetas.Add(new DTOTarjetas
                {
                    idCliente=cliente.Id,
                    Cedula=cliente.Cedula,
                    Nombres=cliente.Nombres,
                    Apellidos=cliente.Apellidos,
                    Email=cliente.Email,
                    idTarjeta=tarjeta.Id,
                    Bin = tarjeta.Bin,
                    Cvv=tarjeta.Cvv,
                    Vencimiento=tarjeta.Vencimiento,
                    Monto=tarjeta.Monto,
                    Balance=tarjeta.Balance
                });
            }
            return tarjetas;
        }

        public static List<Tarjeta> getTarjetasWhere(int id)
        {
            return db.Tarjetas.Where(t => t.IdCliente == id && t.Activo == 1).ToList();
        }

        public static void SaveTarjetas(Tarjeta tarjeta)
        {
            db.Tarjetas.Add(tarjeta);
            db.SaveChanges();
        }

        public static DTOTarjetas getTarjeta(int id)
        {
            Tarjeta tarjeta = db.Tarjetas.First(t => t.Id == id);
            Cliente cliente = db.Clientes.First(c => c.Id == tarjeta.IdCliente);
            return new DTOTarjetas
            {
                idCliente = cliente.Id,
                Cedula = cliente.Cedula,
                Nombres = cliente.Nombres,
                Apellidos = cliente.Apellidos,
                Email = cliente.Email,
                idTarjeta = tarjeta.Id,
                Bin = tarjeta.Bin,
                Cvv = tarjeta.Cvv,
                Vencimiento = tarjeta.Vencimiento,
                Monto = tarjeta.Monto,
                Balance = tarjeta.Balance
            };
        }

        public static void updateTarjeta(Tarjeta tarjeta)
        {
            Tarjeta datos = db.Tarjetas.First(t=>t.Id==tarjeta.Id);
            datos.Bin = tarjeta.Bin;
            datos.Cvv=tarjeta.Cvv;
            datos.Vencimiento = tarjeta.Vencimiento;
            datos.IdCliente = tarjeta.IdCliente;
            datos.Monto = tarjeta.Monto;
            datos.Balance += tarjeta.Balance;
            db.SaveChanges();
        }

        public static void deleteTarjeta(int id)
        {
            Tarjeta tarjeta = db.Tarjetas.First(t => t.Id == id);
            tarjeta.Activo = 0;
            db.SaveChanges();
        }

        public static void pagarTarjeta(DTOTC dtotc)
        {
            Cuenta cuenta = db.Cuentas.First(c => c.Id == dtotc.IdCuenta && c.Activo == 1);
            Tarjeta tarjeta = db.Tarjetas.First(t => t.Id == dtotc.IdTarjeta && t.Activo == 1);
            if (cuenta.Balance >= tarjeta.Balance)
            {
                Historial historial = new Historial
                {
                    Monto = tarjeta.Balance,
                    Tipo = "Pago a la tarjeta",
                    Producto = 2,
                    IdCliente = tarjeta.IdCliente,
                    IdProducto = tarjeta.Id,
                    Fecha = DateTime.Now
                };
                db.Historials.Add(historial);
                cuenta.Balance -= tarjeta.Balance;
                tarjeta.Balance = 0;
                db.SaveChanges();
            }
            else
            {
                throw new Exception();
            }
        }

        public static List<Historial> HistorialTarjetas(int id)
        {
            try
            {
                return db.Historials.Where(h => h.IdProducto == id && h.Producto == 2).ToList();
            }
            catch (Exception e)
            {
                return new List<Historial>();
            }
        }

        public static List<Historial> HistorialTarjetas(int id, DateTime? inicial, DateTime? final)
        {
            try
            {
                return db.Historials.Where(h => h.Fecha >= inicial && h.Fecha <= final && h.IdProducto == id && h.Producto == 2).ToList();
            }
            catch (Exception e)
            {
                return new List<Historial>();
            }
        }

        public static void avanzarTarjeta(DTOTC dtotc)
        {
            Cuenta cuenta = db.Cuentas.First(c => c.Id == dtotc.IdCuenta && c.Activo == 1);
            Tarjeta tarjeta = db.Tarjetas.First(t => t.Id == dtotc.IdTarjeta && t.Activo == 1);
            Historial historial = new Historial
            {
                Monto = dtotc.TarjetaBalance,
                Tipo="Avance en efectivo",
                Producto = 2,
                IdCliente = tarjeta.IdCliente,
                IdProducto = tarjeta.Id,
                Fecha = DateTime.Now
            };
            db.Historials.Add(historial);
            if ((tarjeta.Monto - tarjeta.Balance) >= dtotc.TarjetaBalance)
            {
                cuenta.Balance += dtotc.TarjetaBalance;
                tarjeta.Balance += dtotc.TarjetaBalance;
                db.SaveChanges();
            }
            else
            {
                throw new Exception();
            }
        }

        public static List<LoginEmpleado> getLoginEmpleados()
        {
            return db.LoginEmpleados.Where(l=>l.Activo==1).ToList();
        }

        public static void SaveUsuario(LoginEmpleado usuario)
        {
            db.LoginEmpleados.Add(usuario);
            usuario.Constraseña = Hash.Hashear(usuario.Constraseña);
            db.SaveChanges();
        }

        public static LoginEmpleado getLoginEmpleado(int id)
        {
            return db.LoginEmpleados.First(e=>e.Id==id);
        }

        public static void updateUsuario(LoginEmpleado usuario)
        {
            LoginEmpleado datos = db.LoginEmpleados.First(le => le.Id == usuario.Id);
            datos.Usuario = usuario.Usuario;
            datos.Constraseña = Hash.Hashear(usuario.Constraseña);
            db.SaveChanges();
        }

        public static void deleteUsuario(int id)
        {
            LoginEmpleado usuario = db.LoginEmpleados.First(le => le.Id == id);
            usuario.Activo = 0;
            db.SaveChanges();
        }
    }
}