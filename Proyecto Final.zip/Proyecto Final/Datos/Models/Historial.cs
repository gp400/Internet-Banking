﻿using System;
using System.Collections.Generic;

namespace Datos.Models
{
    public partial class Historial
    {
        public int Id { get; set; }
        public decimal Monto { get; set; }
        public string? Tipo { get; set; }
        public int Producto { get; set; }
        public int IdCliente { get; set; }
        public int IdProducto { get; set; }
        public DateTime? Fecha { get; set; }
    }
}
