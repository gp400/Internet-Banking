﻿using System;
using System.Collections.Generic;

namespace Datos.Models
{
    public partial class Cuenta
    {
        public int Id { get; set; }
        public string NoCuenta { get; set; } = null!;
        public decimal Balance { get; set; }
        public int Activo { get; set; }
        public int IdCliente { get; set; }

        public virtual Cliente IdClienteNavigation { get; set; } = null!;
    }
}
