﻿using System;
using System.Collections.Generic;

namespace Datos.Models
{
    public partial class LoginEmpleado
    {
        public int Id { get; set; }
        public string Usuario { get; set; } = null!;
        public string Constraseña { get; set; } = null!;
        public int? Activo { get; set; }
    }
}
