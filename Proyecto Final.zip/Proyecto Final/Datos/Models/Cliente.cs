﻿using System;
using System.Collections.Generic;

namespace Datos.Models
{
    public partial class Cliente
    {
        public Cliente()
        {
            Cuenta = new HashSet<Cuenta>();
            Prestamos = new HashSet<Prestamo>();
            Tarjeta = new HashSet<Tarjeta>();
        }

        public int Id { get; set; }
        public string Cedula { get; set; } = null!;
        public string Nombres { get; set; } = null!;
        public string Apellidos { get; set; } = null!;
        public DateTime FechaCreacion { get; set; }
        public string Email { get; set; } = null!;
        public string Constraseña { get; set; } = null!;
        public int Activo { get; set; }

        public virtual ICollection<Cuenta> Cuenta { get; set; }
        public virtual ICollection<Prestamo> Prestamos { get; set; }
        public virtual ICollection<Tarjeta> Tarjeta { get; set; }
    }
}
