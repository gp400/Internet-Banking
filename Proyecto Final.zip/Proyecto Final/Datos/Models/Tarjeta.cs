﻿using System;
using System.Collections.Generic;

namespace Datos.Models
{
    public partial class Tarjeta
    {
        public int Id { get; set; }
        public string Bin { get; set; } = null!;
        public int Cvv { get; set; }
        public DateTime Vencimiento { get; set; }
        public int IdCliente { get; set; }
        public decimal Monto { get; set; }
        public decimal Balance { get; set; }
        public int Activo { get; set; }

        public virtual Cliente IdClienteNavigation { get; set; } = null!;
    }
}
