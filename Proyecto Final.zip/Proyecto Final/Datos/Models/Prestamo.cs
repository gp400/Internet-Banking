﻿using System;
using System.Collections.Generic;

namespace Datos.Models
{
    public partial class Prestamo
    {
        public int Id { get; set; }
        public decimal Monto { get; set; }
        public decimal TotalPagado { get; set; }
        public DateTime? FechaInicial { get; set; }
        public DateTime? FechaLimite { get; set; }
        public int Activo { get; set; }
        public int IdCliente { get; set; }

        public virtual Cliente IdClienteNavigation { get; set; } = null!;
    }
}
