﻿using System;
using System.Collections.Generic;

namespace Datos.Models
{
    public partial class Empleado
    {
        public int Id { get; set; }
        public string Cedula { get; set; } = null!;
        public string Nombres { get; set; } = null!;
        public string Apellidos { get; set; } = null!;
        public DateTime FechaIngreso { get; set; }
        public int Activo { get; set; }
    }
}
