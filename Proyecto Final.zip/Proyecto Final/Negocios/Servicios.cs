﻿using Datos;
using Datos.Models;

namespace Negocios
{
    public class Servicios
    {
        public static string[] Login(string username, string password)
        {
            string[] datos = new string[3];
            try
            {
                datos[0] = "1";
                datos[1] = "/Administracion/Index";
                datos[2] = ((LoginEmpleado)Database.Login(username, password)[0]).Usuario;
            }
            catch (Exception e)
            {
                try
                {
                    datos[0] = "2";
                    datos[1] = "/Clientes/Index";
                    datos[2] = ((Cliente)Database.Login(username, password)[0]).Id.ToString();
                }
                catch (Exception er)
                {
                    datos[0] = "0";
                    datos[1] = "/?error=1";
                }
            }
            return datos;
        }
        public static List<Cliente> getClientes()
        {
            return Database.getClientes();
        }

        public static void SaveClientes(Cliente cliente)
        {
            Database.SaveClientes(cliente);
        }

        public static Cliente getCliente(int id)
        {
            return Database.getCliente(id);
        }

        public static void updateCliente(Cliente cliente)
        {
            Database.updateCliente(cliente);
        }

        public static void deleteCliente(int id)
        {
            Database.deleteCliente(id);
        }

        public static List<DTOPrestamos> getPrestamos()
        {
            return Database.getPrestamos();
        }

        public static List<Prestamo> getPrestamosWhere(int id)
        {
            return Database.getPrestamosWhere(id);
        }

        public static void SavePrestamos(Prestamo prestamo)
        {
            Database.SavePrestamos(prestamo);
        }

        public static DTOPrestamos getPrestamo(int id)
        {
            return Database.getPrestamo(id);
        }

        public static void updatePrestamo(Prestamo prestamo)
        {
            Database.updatePrestamo(prestamo);
        }

        public static void deletePrestamos(int id)
        {
            Database.deletePrestamos(id);
        }

        public static void pagarPrestamo(Prestamo prestamo)
        {
            Database.pagarPrestamo(prestamo);
        }

        public static List<Historial> HistorialPrestamos(int id)
        {
            return Database.HistorialPrestamos(id);
        }

        public static List<Historial> HistorialPrestamos(int id, DateTime? inicial, DateTime? final)
        {
            return Database.HistorialPrestamos(id, inicial, final);
        }

        public static List<DTOCuentas> getCuentas()
        {
            return Database.getCuentas();
        }

        public static List<Cuenta> getCuentasWhere(int id)
        {
            return Database.getCuentasWhere(id);
        }

        public static void SaveCuentas(Cuenta cuenta)
        {
            Database.SaveCuentas(cuenta);
        }

        public static DTOCuentas getCuenta(int id)
        {
            return Database.getCuenta(id);
        }

        public static void updateCuenta(Cuenta cuenta)
        {
            Database.updateCuenta(cuenta);
        }

        public static void deleteCuenta(int id)
        {
            Database.deleteCuenta(id);
        }

        public static void retiroCuenta(Cuenta cuenta)
        {
            Database.retiroCuenta(cuenta);
        }

        public static void depositoCuenta(Cuenta cuenta)
        {
            Database.depositoCuenta(cuenta);
        }

        public static List<Historial> HistorialCuentas(int id)
        {
            return Database.HistorialCuentas(id);
        }

        public static List<Historial> HistorialCuentas(int id, DateTime? inicial, DateTime? final)
        {
            return Database.HistorialCuentas(id, inicial, final);
        }

        public static void TransferenciaCuenta(Cuenta cuenta)
        {
            Database.TransferenciaCuenta(cuenta);
        }

        public static List<DTOTarjetas> getTarjetas()
        {
            return Database.getTarjetas();
        }

        public static List<Tarjeta> getTarjetasWhere(int id)
        {
            return Database.getTarjetasWhere(id);
        }

        public static void SaveTarjetas(Tarjeta tarjeta)
        {
            Database.SaveTarjetas(tarjeta);
        }

        public static DTOTarjetas getTarjeta(int id)
        {
            return Database.getTarjeta(id);
        }

        public static void updateTarjeta(Tarjeta tarjeta)
        {
            Database.updateTarjeta(tarjeta);
        }

        public static void deleteTarjeta(int id)
        {
            Database.deleteTarjeta(id);
        }

        public static void pagarTarjeta(DTOTC dtotc)
        {
            Database.pagarTarjeta(dtotc);
        }

        public static List<Historial> HistorialTarjetas(int id)
        {
            return Database.HistorialTarjetas(id);
        }

        public static List<Historial> HistorialTarjetas(int id, DateTime? inicial, DateTime? final)
        {
            return Database.HistorialTarjetas(id, inicial, final);
        }

        public static void avanzarTarjeta(DTOTC dtotc)
        {
            Database.avanzarTarjeta(dtotc);
        }

        public static List<LoginEmpleado> getLoginEmpleados()
        {
            return Database.getLoginEmpleados();
        }

        public static void SaveUsuario(LoginEmpleado usuario)
        {
            Database.SaveUsuario(usuario);
        }

        public static LoginEmpleado getLoginEmpleado(int id)
        {
            return Database.getLoginEmpleado(id);
        }

        public static void updateUsuario(LoginEmpleado usuario)
        {
            Database.updateUsuario(usuario);
        }

        public static void deleteUsuario(int id)
        {
            Database.deleteUsuario(id);
        }
    }
}