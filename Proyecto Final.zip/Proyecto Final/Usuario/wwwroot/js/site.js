﻿function Limpiar() {
    let form = document.querySelector("form");
    form.reset();
    form.classList.remove("was-validated");
}

function LimpiarUpdate() {
    let form = document.querySelector("form");
    let inputs = form.querySelectorAll("input");
    for (let input = 0; input < inputs.length; input++) {
        if (inputs[input].type == "hidden" || inputs[input].type == "submit") {
            continue;
        }
        inputs[input].value = "";
    }
    form.classList.remove("was-validated");
}