﻿using Microsoft.AspNetCore.Mvc;
using Negocios;

namespace Usuario.Controllers
{
    public class Sesiones : Controller
    {
        public IActionResult Login(int error=0)
        {
            ViewBag.error = error;
            return View();
        }

        [HttpPost]
        public IActionResult Login(string username, string password)
        {
            IActionResult retorno = null;
            string[] info = Servicios.Login(username, password);
            if (info[0] == "0")
            {
                retorno = Redirect(info[1]);
            } else if (info[0] == "1")
            {
                HttpContext.Session.SetInt32("tipo", 1);
                HttpContext.Session.SetString("username", info[2]);
                retorno = Redirect(info[1]);
            } else if (info[0] == "2")
            {
                HttpContext.Session.SetInt32("tipo", 2);
                HttpContext.Session.SetString("id", info[2]);
                retorno = Redirect(info[1]);
            }
            return retorno;
        }

        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return Redirect("/");
        }
    }
}
