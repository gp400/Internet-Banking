﻿using Microsoft.AspNetCore.Mvc;
using Negocios;
using Datos.Models;
using Datos;
using XSystem.Security.Cryptography;

namespace Usuario.Controllers
{
    public class Administracion : Controller
    {
        public IActionResult Index()
        {
            return Redirigir();
        }

        public IActionResult Clientes()
        {
            ViewBag.clientes = Servicios.getClientes();
            return Redirigir();
        }

        public IActionResult AgregarCliente()
        {
            ViewBag.mensaje = "Agregar";
            return Redirigir();
        }

        [HttpPost]
        public IActionResult AgregarCliente(Cliente cliente)
        {
            Servicios.SaveClientes(cliente);
            return Redirigir();
        }

        public IActionResult EditarCliente(int id)
        {
            Cliente cliente = Servicios.getCliente(id);
            ViewBag.id = cliente.Id;
            ViewBag.cedula = cliente.Cedula;
            ViewBag.nombre = cliente.Nombres;
            ViewBag.apellido = cliente.Apellidos;
            ViewBag.email = cliente.Email;
            ViewBag.password = cliente.Constraseña;
            ViewBag.mensaje = "Editar";
            return Redirigir();
        }

        [HttpPost]
        public IActionResult EditarCliente(Cliente cliente)
        {
            Servicios.updateCliente(cliente);
            return Redirigir();
        }

        [HttpPost]
        public IActionResult EliminarCliente(int id)
        {
            Servicios.deleteCliente(id);
            ViewBag.clientes = Servicios.getClientes();
            return Redirigir();
        }

        public IActionResult Prestamos()
        {
            ViewBag.prestamos = Servicios.getPrestamos();
            return Redirigir();
        }

        public IActionResult AgregarPrestamo()
        {
            ViewBag.clientes = Servicios.getClientes();
            ViewBag.mensaje="Guardar";
            ViewBag.nuevo = true;
            return Redirigir();
        }

        [HttpPost]
        public IActionResult AgregarPrestamo(Prestamo prestamo)
        {
            Servicios.SavePrestamos(prestamo);
            ViewBag.clientes = Servicios.getClientes();
            return Redirigir();
        }

        public IActionResult EditarPrestamo(int id)
        {
            ViewBag.clientes = Servicios.getClientes();
            DTOPrestamos prestamo = Servicios.getPrestamo(id);
            ViewBag.id = prestamo.idPrestamo;
            ViewBag.clienteid = prestamo.idCliente;
            ViewBag.totaltomado = prestamo.Monto;
            ViewBag.fechainicial = Convert.ToDateTime(prestamo.FechaInicial).ToString("yyyy-MM-dd");
            ViewBag.fechalimite = Convert.ToDateTime(prestamo.FechaLimite).ToString("yyyy-MM-dd");
            ViewBag.mensaje = "Editar";
            ViewBag.nuevo = false;
            return Redirigir();
        }

        [HttpPost]
        public IActionResult EditarPrestamo(Prestamo prestamo)
        {
            Servicios.updatePrestamo(prestamo);
            ViewBag.clientes = Servicios.getClientes();
            return Redirigir();
        }

        [HttpPost]
        public IActionResult EliminarPrestamo(int id)
        {
            Servicios.deletePrestamos(id);
            ViewBag.prestamos = Servicios.getPrestamos();
            return Redirigir();
        }

        public IActionResult Cuentas()
        {
            ViewBag.cuentas = Servicios.getCuentas();
            return Redirigir();
        }

        public IActionResult AgregarCuenta()
        {
            ViewBag.clientes = Servicios.getClientes();
            ViewBag.mensaje = "Guardar";
            ViewBag.nuevo = true;
            return Redirigir();
        }

        [HttpPost]
        public IActionResult AgregarCuenta(Cuenta cuenta)
        {
            Servicios.SaveCuentas(cuenta);
            ViewBag.clientes = Servicios.getClientes();
            return Redirigir();
        }

        public IActionResult EditarCuenta(int id)
        {
            ViewBag.clientes = Servicios.getClientes();
            DTOCuentas cuenta = Servicios.getCuenta(id);
            ViewBag.clienteid = cuenta.idCliente;
            ViewBag.NoCuenta = cuenta.NoCuenta;
            ViewBag.id = cuenta.idCuenta;
            ViewBag.mensaje = "Editar";
            ViewBag.nuevo = false;
            return Redirigir();
        }

        [HttpPost]
        public IActionResult EditarCuenta(Cuenta cuenta)
        {
            Servicios.updateCuenta(cuenta);
            ViewBag.clientes = Servicios.getClientes();
            return Redirigir();
        }

        [HttpPost]
        public IActionResult EliminarCuenta(int id)
        {
            Servicios.deleteCuenta(id);
            ViewBag.cuentas = Servicios.getCuentas();
            return Redirigir();
        }

        public IActionResult Tarjetas()
        {
            ViewBag.tarjetas = Servicios.getTarjetas();
            return Redirigir();
        }

        public IActionResult AgregarTarjeta()
        {
            ViewBag.clientes = Servicios.getClientes();
            ViewBag.mensaje = "Guardar";
            ViewBag.edit = false;
            return Redirigir();
        }

        [HttpPost]
        public IActionResult AgregarTarjeta(Tarjeta tarjeta)
        {
            Servicios.SaveTarjetas(tarjeta);
            ViewBag.edit = false;
            ViewBag.clientes = Servicios.getClientes();
            return Redirigir();
        }

        public IActionResult EditarTarjeta(int id)
        {
            ViewBag.clientes = Servicios.getClientes();
            DTOTarjetas tarjeta = Servicios.getTarjeta(id);
            ViewBag.id = tarjeta.idTarjeta;
            ViewBag.clienteid = tarjeta.idCliente;
            ViewBag.BIN = tarjeta.Bin;
            ViewBag.cvv = tarjeta.Cvv;
            ViewBag.vencimiento = tarjeta.Vencimiento.ToString("yyyy-MM-dd");
            ViewBag.monto=tarjeta.Monto;
            ViewBag.mensaje = "Editar";
            ViewBag.edit = true;
            return Redirigir();
        }

        [HttpPost]
        public IActionResult EditarTarjeta(Tarjeta tarjeta)
        {
            Servicios.updateTarjeta(tarjeta);
            ViewBag.clientes = Servicios.getClientes();
            ViewBag.mensaje = "Editar";
            ViewBag.edit = true;
            return Redirigir();
        }

        [HttpPost]
        public IActionResult EliminarTarjeta(int id)
        {
            Servicios.deleteTarjeta(id);
            ViewBag.tarjetas = Servicios.getTarjetas();
            return Redirigir();
        }

        public IActionResult Usuarios()
        {
            ViewBag.empleados = Servicios.getLoginEmpleados();
            return Redirigir();
        }

        public IActionResult AgregarUsuario()
        {
            ViewBag.mensaje = "Guardar";
            return Redirigir();
        }

        [HttpPost]
        public IActionResult AgregarUsuario(string Usuario, string Constraseña)
        {
            Servicios.SaveUsuario(new LoginEmpleado {Usuario=Usuario, Constraseña=Constraseña});
            ViewBag.mensaje = "Guardar";
            return Redirigir();
        }

        public IActionResult EditarUsuario(int id)
        {
            LoginEmpleado usuario = Servicios.getLoginEmpleado(id);
            ViewBag.usuario = usuario.Usuario;
            ViewBag.password = usuario.Constraseña;
            ViewBag.id = id;
            ViewBag.mensaje = "Editar";
            return Redirigir();
        }

        [HttpPost]
        public IActionResult EditarUsuario(int id, string Usuario, string Constraseña)
        {
            Servicios.updateUsuario(new LoginEmpleado { Id = id, Usuario = Usuario, Constraseña = Constraseña });
            return Redirigir();
        }

        [HttpPost]
        public IActionResult EliminarUsuario(int id)
        {
            Servicios.deleteUsuario(id);
            ViewBag.empleados = Servicios.getLoginEmpleados();
            return Redirigir();
        }

        public IActionResult Redirigir()
        {
            if (HttpContext.Session.GetInt32("tipo") == 1)
            {
                return View();
            }
            return Redirect("/");
        }
    }
}
