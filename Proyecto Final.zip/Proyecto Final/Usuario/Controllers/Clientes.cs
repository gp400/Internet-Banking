﻿using Microsoft.AspNetCore.Mvc;
using Negocios;
using Datos;
using Datos.Models;

namespace Usuario.Controllers
{
    public class Clientes : Controller
    {
        public IActionResult Index()
        {
            return Redirigir();
        }

        public IActionResult Cuentas()
        {
            ViewBag.cuentas = Servicios.getCuentasWhere(Convert.ToInt32(HttpContext.Session.GetString("id")));
            return Redirigir();
        }

        public IActionResult RetiroCuentas()
        {
            ViewBag.cuentas = Servicios.getCuentasWhere(Convert.ToInt32(HttpContext.Session.GetString("id")));
            return Redirigir();
        }

        [HttpPost]
        public IActionResult RetiroCuentas(Cuenta cuenta)
        {
            Servicios.retiroCuenta(cuenta);
            ViewBag.cuentas = Servicios.getCuentasWhere(Convert.ToInt32(HttpContext.Session.GetString("id")));
            return Redirigir();
        }

        public IActionResult DepositoCuentas()
        {
            ViewBag.cuentas = Servicios.getCuentasWhere(Convert.ToInt32(HttpContext.Session.GetString("id")));
            return Redirigir();
        }

        [HttpPost]
        public IActionResult DepositoCuentas(Cuenta cuenta)
        {
            Servicios.depositoCuenta(cuenta);
            ViewBag.cuentas = Servicios.getCuentasWhere(Convert.ToInt32(HttpContext.Session.GetString("id")));
            return Redirigir();
        }

        public IActionResult HistorialCuentas(int id)
        {
            ViewBag.datos = Servicios.HistorialCuentas(id);
            ViewBag.id = id;
            return Redirigir();
        }

        [HttpPost]
        public IActionResult HistorialCuenta(int id, DateTime inicial, DateTime final)
        {
            ViewBag.datos = Servicios.HistorialCuentas(id, inicial, final);
            return View();
        }

        public IActionResult TransferenciaCuenta()
        {
            ViewBag.cuentas = Servicios.getCuentasWhere(Convert.ToInt32(HttpContext.Session.GetString("id")));
            return Redirigir();
        }

        [HttpPost]
        public IActionResult TransferenciaCuenta(Cuenta cuenta)
        {
            Servicios.TransferenciaCuenta(cuenta);
            ViewBag.cuentas = Servicios.getCuentasWhere(Convert.ToInt32(HttpContext.Session.GetString("id")));
            return Redirigir();
        }

        public IActionResult Tarjetas()
        {
            ViewBag.tarjetas = Servicios.getTarjetasWhere(Convert.ToInt32(HttpContext.Session.GetString("id")));
            return Redirigir();
        }

        public IActionResult PagosTarjetas(int id)
        {
            ViewBag.id = id;
            ViewBag.cuentas = Servicios.getCuentasWhere(Convert.ToInt32(HttpContext.Session.GetString("id")));
            return Redirigir();
        }

        [HttpPost]
        public IActionResult PagosTarjetas(DTOTC dtotc)
        {
            Servicios.pagarTarjeta(dtotc);
            ViewBag.cuentas = Servicios.getCuentasWhere(Convert.ToInt32(HttpContext.Session.GetString("id")));
            return Redirigir();
        }

        public IActionResult HistorialTarjetas(int id)
        {
            ViewBag.datos = Servicios.HistorialTarjetas(id);
            ViewBag.id = id;
            return Redirigir();
        }

        [HttpPost]
        public IActionResult HistorialTarjeta(int id, DateTime inicial, DateTime final)
        {
            ViewBag.datos = Servicios.HistorialTarjetas(id, inicial, final);
            return View();
        }

        public IActionResult AvanceTarjetas(int id)
        {
            ViewBag.id = id;
            ViewBag.cuentas = Servicios.getCuentasWhere(Convert.ToInt32(HttpContext.Session.GetString("id")));
            return Redirigir();
        }

        [HttpPost]
        public IActionResult AvanceTarjetas(DTOTC dtotc)
        {
            Servicios.avanzarTarjeta(dtotc);
            ViewBag.cuentas = Servicios.getCuentasWhere(Convert.ToInt32(HttpContext.Session.GetString("id")));
            return Redirigir();
        }

        public IActionResult Prestamos()
        {
            ViewBag.prestamos = Servicios.getPrestamosWhere(Convert.ToInt32(HttpContext.Session.GetString("id")));
            return Redirigir();
        }

        public IActionResult PagarPrestamo(int id)
        {
            ViewBag.id = id;
            ViewBag.cuentas = Servicios.getCuentasWhere(Convert.ToInt32(HttpContext.Session.GetString("id")));
            return Redirigir();
        }

        [HttpPost]
        public IActionResult PagarPrestamo(Prestamo prestamos)
        {
            Servicios.pagarPrestamo(prestamos);
            ViewBag.cuentas = Servicios.getCuentasWhere(Convert.ToInt32(HttpContext.Session.GetString("id")));
            return Redirigir();
        }

        public IActionResult HistorialPrestamos(int id)
        {
            ViewBag.datos = Servicios.HistorialPrestamos(id);
            ViewBag.id = id;
            return Redirigir();
        }

        [HttpPost]
        public IActionResult HistorialPrestamo(int id, DateTime inicial, DateTime final)
        {
            ViewBag.datos = Servicios.HistorialPrestamos(id, inicial, final);
            return View();
        }

        public IActionResult Redirigir()
        {
            if (HttpContext.Session.GetInt32("tipo") == 2)
            {
                ViewBag.cliente = Servicios.getCliente(Convert.ToInt32(HttpContext.Session.GetString("id")));
                return View();
            }
            return Redirect("/");
        }
    }
}
